# 字符串拼接
str1 = input("请输入一个人的名字: ")
str2 = input("请输入一个国家的名字：")
print("世界这么大，{}想去看看{}。".format(str1, str2))
