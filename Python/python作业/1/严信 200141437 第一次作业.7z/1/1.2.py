# 计算1加到n
n = input("请输入整数N：")
sum = 0
for i in range(int(n)):
    sum += i + 1
print("1到N求和结果：",sum)