# 田字格
for i in range(11):
    if i in [0, 5, 10]:
        print("+ - - - - + - - - - +")
    else:
        print("|         |         |")
