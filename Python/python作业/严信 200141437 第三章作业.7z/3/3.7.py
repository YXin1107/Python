# 文本风格
while True:
    for i in ["/", "-", "\\", "|"]:
        print("%s\r" % i, end='')
